"""Launch the root jupyter command"""
from .command import main
main()
